package pojo;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
@JsonAutoDetect(
		  fieldVisibility = Visibility.ANY,
		  getterVisibility = Visibility.NONE,
		  setterVisibility = Visibility.NONE,
		  creatorVisibility = Visibility.NONE
		) 
public class GetRequest {
	@JsonProperty(value = "OrganizationCode")
	private String OrganizationCode;
	
	@JsonProperty(value = "MemberHCID")
	private String MemberHCID;
	
	@JsonProperty(value = "MemberCode")
	private String MemberCode;
	
	@JsonProperty(value = "MemberCase")
	private String MemberCase;
	
	@JsonProperty(value = "MemberContract")
	private String MemberContract;
	
	@JsonProperty(value = "AccumStartDate")
	private String AccumStartDate;
	
	@JsonProperty(value = "AccumEndDate")
	private String AccumEndDate;
	
	@JsonProperty(value = "ClaimNetwork")
	private String ClaimNetwork;
		
	@JsonProperty(value = "AccumName")
	private String AccumName;
	
	@JsonProperty(value = "MemberTier")
	private String MemberTier;
	
	@JsonProperty(value = "ProviderTaxId")
	private String ProviderTaxId;
	
	@JsonProperty(value = "DiagnosisCode")
	private String DiagnosisCode;
	
	@JsonProperty(value = "ServiceStartDate")
	private String ServiceStartDate;
	

	@JsonProperty(value = "ServiceEndDate")
	private String ServiceEndDate;
	
	public String getServiceStartDate() {
		return ServiceStartDate;
	}

	public void setServiceStartDate(String serviceStartDate) {
		ServiceStartDate = serviceStartDate;
	}

	public String getServiceEndDate() {
		return ServiceEndDate;
	}

	public void setServiceEndDate(String serviceEndDate) {
		ServiceEndDate = serviceEndDate;
	}
	
	public String getOrganizationCode() {
		return OrganizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		OrganizationCode = organizationCode;
	}

	public String getMemberHCID() {
		return MemberHCID;
	}

	public void setMemberHCID(String memberHCID) {
		MemberHCID = memberHCID;
	}

	
	public String getMemberCode() {
		return MemberCode;
	}

	public void setMemberCode(String memberCode) {
		MemberCode = memberCode;
	}

	public String getMemberCase() {
		return MemberCase;
	}

	public void setMemberCase(String memberCase) {
		MemberCase = memberCase;
	}

	public String getMemberContract() {
		return MemberContract;
	}

	public void setMemberContract(String memberContract) {
		MemberContract = memberContract;
	}

	public String getAccumStartDate() {
		return AccumStartDate;
	}

	public void setAccumStartDate(String accumStartDate) {
		AccumStartDate = accumStartDate;
	}

	public String getAccumEndDate() {
		return AccumEndDate;
	}

	public void setAccumEndDate(String accumEndDate) {
		AccumEndDate = accumEndDate;
	}

	public String getClaimNetwork() {
		return ClaimNetwork;
	}

	public void setClaimNetwork(String claimNetwork) {
		ClaimNetwork = claimNetwork;
	}

	public String getAccumName() {
		return AccumName;
	}

	public void setAccumName(String accumName) {
		AccumName = accumName;
	}

	public String getMemberTier() {
		return MemberTier;
	}

	public void setMemberTier(String memberTier) {
		MemberTier = memberTier;
	}

	public String getProviderTaxId() {
		return ProviderTaxId;
	}

	public void setProviderTaxId(String providerTaxId) {
		ProviderTaxId = providerTaxId;
	}

	public String getDiagnosisCode() {
		return DiagnosisCode;
	}

	public void setDiagnosisCode(String diagnosisCode) {
		DiagnosisCode = diagnosisCode;
	}


}
